import pytest
import allure
from tools.routes import AppRoute
from pages.authentication.login_page import LoginPage  # Импортируем LoginPage



@pytest.mark.regression
@pytest.mark.authorization
@pytest.mark.parametrize(
    "email, password",
    [
        ("user.name@gmail.com", "password"),
        ("user.name@gmail.com", "  "),
        ("  ", "password")
    ]
)
@allure.title("User login with wrong email or password")
def test_wrong_email_or_password_authorization(login_page: LoginPage, email: str, password: str):
    login_page.visit(AppRoute.LOGIN)
    login_page.login_form.fill_login_form(email=email, password=password)
    login_page.click_login_button()
    login_page.check_visible_wrong_email_or_password_alert()

